// Get canvas element and context
const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');

const fps30 = 30;
const fps60 = 60;

var hits = 0;
var fails = 0;

/* FUTURE SUPPORT TO JOYSTICK */
var joy3Param = { "title": "joystick3" };
var Joy3 = null;
var joy3IinputPosX = null;
var joy_touch = null;

try {
	Joy3 = new JoyStick('joy3Div', joy3Param);
    joy3IinputPosX = document.getElementById("joy3PosizioneX");
}
catch (e) {}

// Define bar properties
const barWidth = canvas.width;
const barHeight = 10;
const barX = 0;
const barY = barHeight * 16; // 160
var barColor = "#E6E6E6";

// Define tank properties
var tankHeight = 110;
var tankWidth = 80;
var tankX = 160;
var tankY = canvas.height - 110;

// Define ball properties
const ballRadius = 10;
var ballX = tankX + (tankWidth / 2);
var ballY = tankY - ballRadius;
var ballSpeed = 9;
var ballLaunched = false;
var ballColor = "red";

// Define duck properties
const duckSizeFactor = 0.26;
const duckHeight = 800 * duckSizeFactor; // 208
const duckY = barY - 60;
var totalDucks = 6;

var ImgDuck = [];
for (var i = 0; i < 48; i++) {
	ImgDuck[i] = new Image();
	ImgDuck[i].src = "img/duck/"+i+".gif";
}

// Define border limit
var screenLimitLeft = tankWidth * 2;
var screenLimitRight = tankWidth * 9;

// timer
var chronometer;

const simpleTextStyler = (function(){
    const simpleTextStyler = {
        sizes: [],
        baseSize: undefined,
        font: undefined,
        controlChars: "{}\n\t",
        spaceSize: 0,
        tabSize: 8, // in spaceSize units
        tabs: (function() {var t = []; for(var i=0; i < 100; i += 8){t.push(i);}; return t;})(),
        getNextTab: function(x) {
            var i = 0;
            while (i < this.tabs.length) {
                if (x < this.tabs[i] * this.tabSize * this.spaceSize) {
                    return this.tabs[i] * this.tabSize * this.spaceSize;
                }
                i++;
            }
            return this.tabs[i-1] * this.tabSize * this.spaceSize;
        },
        getFontSize: function(font){
            var numFind = /[0-9]+/;
            var number = numFind.exec(font)[0];
            if (isNaN(number)) {
                throw Error("SimpleTextStyler Cant find font size");
            }
            return Number(number);
        },
        setFont: function(font = ctx.font) {
            this.font = ctx.font = font;
            this.baseSize = this.getFontSize(font);
            for (var i = 32; i < 256; i ++) {
                this.sizes[i - 32] = ctx.measureText(String.fromCharCode(i), 0, 0).width/this.baseSize;
            }
            this.spaceSize = this.sizes[0];
        },
        drawText: function(context, text, x, y, size) {
            var i, len, subText;
            var w, scale;
            var xx, yy, ctx;
            var state = [];
            if(text === undefined){ return }
            xx = x;
            yy = y;
            if (!context.setTransform) { // simple test if this is a 2D context
                if (context.ctx) { ctx = context.ctx } // may be a image with attached ctx?
                else{ return }
            } else { ctx = context }

            function renderText(text) {
                ctx.save();
                ctx.fillStyle = colour;
                ctx.translate(x, y)
                ctx.scale(scale, scale)
                ctx.fillText(text, 0, 0);
                ctx.restore();
            }
            var colour = ctx.fillStyle;
            ctx.font = this.font;
            len = text.length;
            subText = "";
            w = 0;
            i = 0;
            scale = size / this.baseSize;
            while (i < len) {
                const c = text[i];
                const cc = text.charCodeAt(i);
                if (cc < 256) { // only ascii
                    if (this.controlChars.indexOf(c) > -1) {
                        if (subText !== "") {
                            scale = size / this.baseSize;
                            renderText(subText);
                            x += w;
                            w = 0;
                            subText = "";                        
                        }
                        if (c === "\n") {  // return move to new line
                            x = xx;
                            y += size;
                        } else if (c === "\t") { // tab move to next tab
                            x = this.getNextTab(x - xx) + xx;
                        } else if (c === "{") {   // Text format delimiter                       
                            state.push({size, colour, x, y})
                            i += 1;
                            const t = text[i];
                            if (t === "+") {  // Increase size
                                size *= 1/(3/4);
                            } else if (t === "-") {  // decrease size
                                size *= 3/4;
                            } else if (t === "s") { // sub script
                                y += size * (1/3);
                                size  *= (2/3);
                            } else if (t === "S") { // super script
                                y -= size * (1/3);
                                size  *= (2/3);
                            } else if (t === "#") {
                                colour = text.substr(i,7);
                                i+= 6;
                            }
                        } else if (c  === "}"){
                            const s = state.pop();
                            y = s.y;
                            size = s.size;
                            colour = s.colour;
                            scale = size / this.baseSize;
                        }
                    } else {
                        subText += c;
                        w += this.sizes[cc-32] * size;
                    }
                 }
                 i += 1;
            }
            if (subText !== "") { renderText(subText) }
        },
    }
    return simpleTextStyler;
})();

// Draw the bar on the canvas
function drawBar() {
	ctx.beginPath();
	// Set the border color
	ctx.strokeStyle = "black";
	// Set the border width
	ctx.lineWidth = 1;
	ctx.fillStyle = barColor;
	ctx.fillRect(barX, barY, barWidth, barHeight);
	ctx.strokeRect(barX, barY, barWidth, barHeight);
	ctx.fill();
	ctx.closePath();
}

class Tank {
	constructor(x, y, width, height, img) {
		this.tankX = x;
		this.tankY = y;
		this.tankWidth = width;
		this.tankHeight = height;
		this.tankImg = img;
	}
  
	moveRight(){
		if (this.tankX < screenLimitRight){
			this.tankX += this.tankWidth;
			ctx.drawImage(this.tankImg, this.tankX, this.tankY, this.tankWidth, this.tankHeight);
			ballX = this.tankX + (this.tankWidth / 2);
		}
	}
	
	moveLeft(){
		if (this.tankX > screenLimitLeft){
			this.tankX -= this.tankWidth;
			ctx.drawImage(this.tankImg, this.tankX, this.tankY, this.tankWidth, this.tankHeight);
			ballX = this.tankX + (this.tankWidth / 2);
		}
	}
	
	moveToStart(){
		this.tankX = 160;
	}

	// Draw the tank on the canvas
	draw() {
		ctx.drawImage(this.tankImg, this.tankX, this.tankY, this.tankWidth, this.tankHeight);
	}
}

// animated ducks
function drawAnimatedImage(arr,x,y,angle,factor,changespeed) {
    if (!factor) {
        factor = 1;
    }
    if (!changespeed) {
        changespeed = fps30;
    }
	ctx.beginPath();
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle * Math.PI / 180);
    if (!!arr[Math.round(Date.now()/changespeed) % arr.length]) {
		ctx.drawImage(
			arr[Math.round(Date.now()/changespeed) % arr.length], 
			-(arr[Math.round(Date.now()/changespeed) % arr.length].width * factor / 2), 
			-(arr[Math.round(Date.now()/changespeed) % arr.length].height * factor / 2), 
			arr[Math.round(Date.now()/changespeed) % arr.length].width * factor, 
			arr[Math.round(Date.now()/changespeed) % arr.length].height * factor
		);
    }
    ctx.restore();
	ctx.closePath();
}

function drawDuck() {
	let x = 200; // Initial x-coordinate
	const step = 110; // Distance between ducks

	for (i = 0; i < totalDucks; i++) {
		drawAnimatedImage(ImgDuck, x, duckY, 0, duckSizeFactor, (i % 2 == 0) ? fps30 : fps60);
		x += step;
	}
}

// Load the image of the tank
var tankImg = new Image();
tankImg.src = "img/tank.png";
var tank = new Tank(tankX, tankY, tankWidth, tankHeight, tankImg)

function drawTank(){
	tank.draw();
}

// Draw the ball on the canvas
function drawBall() {
	let totalPhotonBullets = parseInt(document.getElementById("bullet-select").value);
    if (totalPhotonBullets == 1){
		ctx.beginPath();
		ctx.arc(ballX, ballY, ballRadius, 0, Math.PI*2);
		ctx.fillStyle = ballColor;
		ctx.fill();
		ctx.closePath();		
	}
	else if (totalPhotonBullets == 2){
		ctx.beginPath();
		ctx.arc(ballX-25, ballY, ballRadius, 0, Math.PI*2);
		ctx.arc(ballX+25, ballY, ballRadius, 0, Math.PI*2);
		ctx.fillStyle = ballColor;
		ctx.fill();
		ctx.closePath();		
	}
	else{
		ctx.beginPath();
		ctx.arc(ballX-25, ballY, ballRadius, 0, Math.PI*2);
		ctx.arc(ballX, ballY, ballRadius, 0, Math.PI*2);
		ctx.arc(ballX+25, ballY, ballRadius, 0, Math.PI*2);
		ctx.fillStyle = ballColor;
		ctx.fill();
		ctx.closePath();		
	}
}

// Move the ball upwards on the canvas
function moveBall() {
    ballY -= ballSpeed;
    // checking if ball is on top of the screen
    if (ballLaunched){
		if (ballY <= barY){
			//alert("touched");
			var rangeInput = document.getElementById("mySlider");
			var rangeValue = rangeInput.value;
			// acerto
			if (rangeValue >= freq){
				let totalPhotonBullets = parseInt(document.getElementById("bullet-select").value);
				var nota = calcularNota(rangeValue, freq, lastFreq) * totalPhotonBullets;
				points += nota; // add points
				hits += 1;
				totalDucks-=totalPhotonBullets;
				if (totalDucks < 0){
					totalDucks = 0;
				}
				if (totalDucks == 0){
					const totalPhotonBullets = parseInt(document.getElementById("bullet-select").value);
					const timeElapsed = document.getElementById("timerDiv").innerText;
					const elementSelected = document.getElementById("element-select").value;
					Swal.fire({
					  title: 'Congratulations!',
					  html: `Element: ${elementSelected}<br/>HP: ${energy} | Score: ${points}<br/>Releases: ${hits} | Failures: ${fails}<br/>Time elapsed: ${timeElapsed}`,
					  showCloseButton: true
					})
					gameStarted = false;
				}
			}
			// erro
			else{
				fails += 1;
				damage = calculateEnergyInEvNumericTrunc(parseFloat(rangeValue + "e12"));
				energy -= damage;
				if (energy <= 0) {
					energy = 0;
					Swal.fire({
						title: 'Game Over',
						html: `Try again!`,
						showCloseButton: true
					})
					gameStarted = false;
				}
			}
			ballY = tankY - ballRadius;
			ballLaunched = false;
		}
    }
}

// energy
let energy = 50;

// Add event listener for key presses
document.addEventListener('keydown', function(event) {
    document.activeElement.blur(); // remove focus from currently focused element

	if (gameStarted == true){
		// Move the cannon to the left or right based on the arrow key pressed
		if (event.keyCode === 37) { // left arrow
			tank.moveLeft();
		} 
		else if (event.keyCode === 39) { // right arrow
			tank.moveRight();
		} 
		else if (event.code === 'Space') { // spacebar
			if (ballLaunched == false){
				if (energy > 0){
					ballLaunched = true;
				}
				else{
					alert("Game over");
				}
			}
		}
	}
});

// Add text to show points earned on the canvas
let points = 0;

function drawPoints() {
	ctx.font = "20px Arial";
	ctx.fillStyle = "black";
	simpleTextStyler.setFont(); // set the current font
	//"Testing simple Canvas2D text styler...\nnewline\n\tTab\n\t\tTab\n\t\t\tTab\nSub{sScript} Super{SScript} Size {+Big {+Bigger}} Normal {-Small {-Smaller}}\nAnd now colours \n{#FF0000Red} {#00FF00Green} {#0000FFBlue}",
	simpleTextStyler.drawText(
		ctx,
		`Release the ducks! HP: {#0000FF${energy}} | Score: {#0000FF${points}} | Releases: {#0000FF${hits}} | Failures: {#0000FF${fails}}`,
		10,20,18
	);
}

// Get the combo box element
const elementSelect = document.getElementById("element-select");

// Add an event listener for when the value of the combo box changes
elementSelect.addEventListener("change", function() {
	// Get the selected value
	const selectedValue = elementSelect.value;

	if (selectedValue == "cesium"){
		freq = cesiumFrequency;
		barColor = "#C9AE5D";
	}
	else if (selectedValue == "potassium"){
		freq = potassiumFrequency;
		barColor = "#D5D5D5";
	}
	else if (selectedValue == "sodium"){
		freq = sodiumFrequency;
		barColor = "white";
	}
	else if (selectedValue == "calcium"){
		freq = calciumFrequency;
		barColor = "#E6E6E6";
	}
	else if (selectedValue == "lithium"){
		freq = lithiumFrequency;
		barColor = "#E6E6E6";
	}
	else if (selectedValue == "yttrium"){
		freq = yttriumFrequency;
		barColor = "#E6E6E6";
	}
});

let gameStarted = false;

function updateColor(){
	const slider = document.getElementById('mySlider');
	const sliderWidth = slider.offsetWidth;

	const gradient = ctx.createLinearGradient(0, 0, sliderWidth, 0);
	gradient.addColorStop(0, 'red'); // Red at 380 nm
	gradient.addColorStop(0.2, 'orange'); // Orange at 440 nm
	gradient.addColorStop(0.4, 'yellow'); // Yellow at 490 nm
	gradient.addColorStop(0.6, 'green'); // Green at 540 nm
	gradient.addColorStop(0.8, 'blue'); // Blue at 590 nm
	gradient.addColorStop(1, 'violet'); // Violet at 484 nm

	//document.querySelector('.color-block').style.backgroundColor = gradient;
	console.log(gradient);
}
updateColor();

// Add an event listener to the range input to update the slider value span
document.getElementById("mySlider").addEventListener("input", function() {
  // Set the text content of the slider value span to the current value of the range input
  rangeSpan.textContent = document.getElementById("mySlider").value;
  updateColor();
});

function drawground() {
    //draw the ground
    ctx.fillStyle = "#ffe3a0";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

var riverY = 100;
function drawRiver() {    
    ctx.strokeStyle = 'blue';
    ctx.lineWidth = 2;
	
    // Define the waveform data (sample values)
    const splitPoint1 = (canvas.height / 2) - (canvas.height / 3);
    const splitPoint2 = (canvas.height / 2) - (canvas.height / 30);
	
    const amplitude = 5;    // Controls the height of the wave
    const frequency = 0.03;  // Controls the width of the wave
	
    // Draw the upper part of the waveform
    ctx.beginPath();
    for (let x = 0; x < canvas.width; x++) {
		const y1 = splitPoint1 + amplitude * Math.sin(frequency * x);
		const y2 = splitPoint2 + amplitude * Math.sin(frequency * x);		
		ctx.lineTo(x, y1);
		ctx.lineTo(x, y2);
    }
    ctx.stroke();

}

function drawScenario(){
	ctx.clearRect(0, 0, canvas.width, canvas.height);	
	drawground();
	drawRiver();
	drawBar();
	drawTank();
	drawPoints();
	requestAnimationFrame(drawDuck);
}

var game_screen;
function startGameScreen(){
	game_screen = setInterval(function() {
		drawScenario();
		if (ballLaunched == true) { // check if a ball has been photon already
			moveBall();
			drawBall();
		}
	}, 10);
}
function stopGameScreen(){
	clearInterval(game_screen);
}



function startJoyTouch(){
	joy_touch = setInterval(function() {
		//joy3IinputPosX.value=Joy3.GetPosX();
		if (Joy3.GetPosX() == 25){
			tank.moveLeft();
		}
		if (Joy3.GetPosX() == 75){
			tank.moveRight();
		}
	}, 500);
}

function stopJoyTouch(){
	clearInterval(joy_touch);
}

// Start the timer
function startUpdateTimer(){
	chronometer = setInterval(function() {
		updateTimer();
	}, 1000);
}

function stopUpdateTimer(){
	clearInterval(chronometer);
}

// Add event listener to btnStart
const buttonStart = document.getElementById('btnStart');
buttonStart.addEventListener('click', () => {
	gameStarted = true;
	startGame(gameStarted);
});

function startGame(gameStarted){
	if (gameStarted == true){
		document.getElementById('mySlider').disabled = false;
		document.getElementById('bullet-select').disabled = false;

		document.getElementById('element-select').disabled = true;
		document.getElementById('btnStart').disabled = true;

		energy = 50; // HP
		hits = 0; // releases
		fails = 0; // failures
		tank.moveToStart();
		startUpdateTimer();
		startJoyTouch();
		startGameScreen();
	}
}

window.addEventListener('DOMContentLoaded', function() {
	// console.log('window - DOMContentLoaded - capture'); // 1st
	document.getElementById('element-select').disabled = false;
	document.getElementById('btnStart').disabled = false;
	document.getElementById('btnAbout').disabled = false;
	document.getElementById('btnHowToPlay').disabled = false;
	document.getElementById('btnInfo').disabled = false;
	document.getElementById('btnCredits').disabled = false;
	document.getElementById('btnRestart').disabled = false;
	
	document.getElementById('mySlider').disabled = true;
	document.getElementById('bullet-select').disabled = true;

	gameStarted = false;
	startGame(gameStarted);

	stopUpdateTimer();
	//stopJoyTouch();
	stopGameScreen();
	drawScenario();
}, true);